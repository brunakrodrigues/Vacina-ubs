﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UBS_mvc
{
    public class Appsettings
    {
        public string ConnectionString { get; set; }
    }
}
